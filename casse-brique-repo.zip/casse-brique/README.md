# Casse-brique — style rétro CRT

Un casse-brique (breakout) solo en JavaScript vanilla, sans dépendance, jouable au clavier, à la souris ou au doigt. Esthétique rétro monochrome (noir/blanc + accent vert phosphore) avec effet écran cathodique (scanlines, vignettage) et sons synthétisés en Web Audio (aucun fichier audio externe).

## Jouer

Ouvrir `index.html` dans un navigateur, ou servir le dossier avec n'importe quel serveur statique. Aucune dépendance, aucune étape de build.

**GitHub Pages** : Settings → Pages → Deploy from branch → `main` / `/ (root)`. Le jeu sera servi depuis `index.html`.

## Contrôles

| Action | Desktop | Mobile |
|---|---|---|
| Déplacer la raquette | Flèches ←/→, A/D, ou souris | Glisser le doigt |
| Lancer la balle | Espace / clic | Tap |
| Pause | P ou Échap, ou le bouton ❚❚ | Bouton ❚❚ |

## Fonctionnalités

- Niveaux progressifs (vitesse de balle et largeur de raquette évoluent)
- 3 vies, score, meilleur score sauvegardé en local (`localStorage`)
- Responsive : s'adapte à toute taille d'écran, desktop et smartphone
- Effet CRT (scanlines + vignettage) et sons rétro générés par oscillateurs
- Pause automatique quand l'onglet perd le focus

## Structure

```
.
├── index.html   # jeu complet (HTML + CSS + JS), fichier unique
└── README.md
```

## Licence

MIT — voir [LICENSE](LICENSE).
